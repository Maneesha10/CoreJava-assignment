package com.sonata.arrays;

import java.math.BigDecimal;

public class StudentRunner {

	public static void main(String[] args) {
		int[] marks = {99,59,73};
		Student student =  new Student("Mani", marks);
		
		int number = student.getNumberOfMarks();
		System.out.println("number of marks" + number);
		
		int sum = student.getSumOfMarks();
		System.out.println("Total marks are"+ sum);
		
		int maxMark = student.getMaximumfMarks();
		System.out.println("Maximum marks are"+ maxMark);
		
		int minMark = student.getMinimumfMarks();
		System.out.println("Minimum marks are"+ minMark);
		
		BigDecimal average = student.getAverageMarks();
		System.out.println("average marks are" + average);
		
		//student.addNewMark();
		
		//student.removeNewMark();

	}

}
