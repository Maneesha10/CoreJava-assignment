package com.sonata.functionalprogramming;

import java.util.List;

public class MethodReferenceRunner {
	
	public static void print(Integer number) {
		System.out.println(number);
	}

	public static void main(String[] args) {
		List.of("ant","bat","cat","mice").stream()
		.map(n -> n.length())
		.forEach(s -> System.out.println(s));
		
		List.of("ant","bat","cat","mice").stream()
		.map(String::length)     
		.forEach(MethodReferenceRunner::print);
                   
	}

}
