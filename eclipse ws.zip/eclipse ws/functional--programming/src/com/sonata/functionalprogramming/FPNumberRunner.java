package com.sonata.functionalprogramming;

import java.util.List;

public class FPNumberRunner {

	public static void main(String[] args) {
		List<Integer> list = List.of(3,7,9,12,6,17,10);
		fpNumber(list);

	}

	private static void fpNumber(List<Integer> list) {
		System.out.println(list.stream().reduce(0,(number1,number2) -> number1+number2));
		
	}

}
