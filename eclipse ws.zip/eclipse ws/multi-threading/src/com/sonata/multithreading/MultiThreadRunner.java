package com.sonata.multithreading;

class Task1 extends Thread{
	public void run () {
		System.out.println("\n Task 1 start");
		for(int i=101;i<=199;i++)
			System.out.println(i + " ");
		System.out.println("\n Task 1 done");

	}
}

class Task2 implements Runnable{

	public void run() {
	System.out.println("\n Task 2 start");
	for(int i=201;i<=299;i++)
		System.out.println(i + " ");
	System.out.println("\n Task 2 done");
	}

}

public class MultiThreadRunner {

	public static void main(String[] args) throws InterruptedException {
		//Task 1
		System.out.println("\n Task 1 kicked off");
		Task1 task1 = new Task1();
		task1.setPriority(1);
		task1.start();
		
		System.out.println("\n Task 2 kicked off");
		
		
		//task 2
		Task2 task2 = new Task2();
		Thread task2Thread = new Thread(task2);
		task2Thread.setPriority(10);
		task2Thread.start();
		
		//wait until to complete above tasks
		task1.join();
		task2Thread.join();
		
		//task 3

		System.out.println("\n Task3 kicked off");
		for(int i=301;i<=399;i++)
			System.out.println(i + " ");
		System.out.println("\n Task 3 done");


	}

}
