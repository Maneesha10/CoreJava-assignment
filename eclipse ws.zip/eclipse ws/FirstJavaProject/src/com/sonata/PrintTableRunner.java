package com.sonata;

public class PrintTableRunner {

	public static void main(String[] args) {
		PrintTable tabl = new PrintTable();
		tabl.print(6);
		//tabl.print(6,2,11);

	}

}
