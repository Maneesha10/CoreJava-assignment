package com.sonata;

public class MotorBike {
	private int speed;//member variable
	
	void setSpeed(int speed) { //local variable
		this.speed=speed;
	}
	
	public int getSpeed() {
		return speed;
	}
	
	public void increaseSpeed(int howMuch) {
		this.speed=this.speed+howMuch;
	}
	void start() {
		System.out.println("bike started");
	}
	

	public static void main(String[] args) {
		
		 MotorBike ducati = new MotorBike();
		 MotorBike honda = new MotorBike();
		 
		 ducati.start();
		 honda.start();
		 
		 ducati.setSpeed(100);
		 //System.out.println(ducati.getSpeed());
		/* int ducatiSpeed = ducati.getSpeed();//get ducati speed
		 ducatiSpeed = ducatiSpeed + 100;//incr with 100
		 ducati.setSpeed(ducatiSpeed);//set speed*/ //avoid duplication
		 
		 ducati.increaseSpeed(159);
		 
		 System.out.println(ducati.getSpeed());
		 
		 honda.setSpeed(40);
		 System.out.println(honda.getSpeed());
		 
		 
		 

	}

}
