package com.sonata.programs;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sonata.cfg.AppConfig1;
import com.sonata.dao.ProductDao;

public class P01_GetProductCount {
	
	public static void main(String[] args) {
		//our dependency
		ProductDao dao;
		
		//a variable representing the spring
		AnnotationConfigApplicationContext ctx;
		
		//object of a spring container
		ctx = new AnnotationConfigApplicationContext(AppConfig1.class);
		
		System.out.println("--------------------");
		
		dao = ctx.getBean("JdbcDao",ProductDao.class);
		ProductDao dao2 = ctx.getBean("JdbcDao",ProductDao.class);
		
		System.out.println("dao2 == dao is" + (dao2==dao));
		
		System.out.println("dao is instance of" + dao.getClass().getName());
		System.out.println("There are" + dao.count() + "products");
		
		ctx.close();
	}

}
