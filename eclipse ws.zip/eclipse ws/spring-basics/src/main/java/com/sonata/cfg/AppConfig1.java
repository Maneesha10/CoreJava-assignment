package com.sonata.cfg;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import com.sonata.dao.DummyProductDao;
import com.sonata.dao.JdbcProductDao;

import lombok.Value;

@Configuration
@PropertySource("classpath:jdbc.properties")
public class AppConfig1 {
	
	@Value("${jdbc.driver}")
	private String driverClassName;
	@Value("${jdbc.url}")
	private String url;
	@Value("${jdbc.user}")
	private String user;
	@Value("${jdbc.password}")
	private String password;
	
	public AppConfig1() {
		System.out.println("AppConfig1 instantiated");
	
	}
	
	@Lazy
	@Bean
	public DummyProductDao DummyDao() {
		System.out.println("AppConfig1 DummyDao() called");
		return new DummyProductDao();
	}
	
	@Lazy
	@Scope("singleton")
	@Bean
	public JdbcProductDao JdbcDao() {
		System.out.println("AppConfig1 JdbcDao() called");
		JdbcProductDao dao = new JdbcProductDao();
		dao.setDriverClassName(driverClassName);
		dao.setUrl(url);
		dao.setUser(user);
		dao.setPassword(password);
		
		
		return dao;
	}

}
