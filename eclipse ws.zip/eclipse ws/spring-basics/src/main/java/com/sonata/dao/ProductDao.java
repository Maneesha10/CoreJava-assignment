package com.sonata.dao;

public interface ProductDao {
	//CRUD OPERATONS
	
	//QUERIES
	public long count();

}
