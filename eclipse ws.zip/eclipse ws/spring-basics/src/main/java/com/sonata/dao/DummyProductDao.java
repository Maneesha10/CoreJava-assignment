package com.sonata.dao;

public class DummyProductDao implements ProductDao {

	public long count() {
				return 0;
	}

}
