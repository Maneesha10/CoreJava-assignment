package com.sonata.cfg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

import com.sonata.dao.DummyProductDao;
import com.sonata.dao.JdbcProductDao;

import lombok.Value;

@Configuration
@PropertySource("classpath:jdbc.properties")
public class AppConfig1 {
	
	@Value("${jdbc.driver}")
	private String driverClassName;
	@Value("${jdbc.url}")
	private String url;
	@Value("${jdbc.user}")
	private String user;
	@Value("${jdbc.password}")
	private String password;
	
	@Bean
	public Connection createConnection() throws ClassNotFoundException, SQLException {
		Class.forName(driverClassName);
		return DriverManager.getConnection(url, user, password);
				}
	
	@Bean
	public JdbcProductDao JdbcDao(Connection connection) { //injection
		JdbcProductDao dao = new JdbcProductDao();
		dao.setConnection(connection);// manual wiring
		
		
		return dao;
	}

}
