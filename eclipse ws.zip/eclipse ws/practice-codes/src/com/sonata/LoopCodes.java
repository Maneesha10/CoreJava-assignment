package com.sonata;

import java.util.Scanner;

public class LoopCodes {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		
		/*int sum = 0;
		
		for(int i =0; i<10;i++) {
			System.out.println("enter a number:");
			int n=scanner.nextInt();
			sum=sum+n;
		}
         System.out.println("sum is" +sum);
		
		int n=5;
		for(int i=1;i<n;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}*/
		
		int rows = 5;
		System.out.println("## Printing the pattern ##");
 		for (int i = 1; i <= rows; i++) 
                { 
                        for (int j = rows; j > i; j--)
			{
				System.out.print(" ");
			}
			for (int k = 1; k <= i; k++)
			{
				System.out.print(k + " ");
			}
			System.out.println();
		}
	}

}
